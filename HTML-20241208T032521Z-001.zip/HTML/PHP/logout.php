<?php
session_start();
session_destroy();
header('Location: landing_no_acc.html');
?>
